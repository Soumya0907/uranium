const printDate = function(){
    console.log('06-04-2022')
}

const printMonth = function(){
    console.log('April')
}

const getBatchInfo = function(){
    console.log('Uranium, W3D1, the topic for today is Nodejs module system')
}
module.exports.printDate = printDate
module.exports.printMonth = printMonth
module.exports.getBatchInfo = getBatchInfo