let str1 = " UraniumBatch ".trim()
let str2 = "SOUMYA JHA" .toLowerCase()
let str3 = "function up" .toUpperCase()

module.exports.str1 = str1
module.exports.str2 = str2
module.exports.str3 = str3
