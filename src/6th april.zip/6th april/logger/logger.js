const welcome = function(){
    console.log("Welcome to my application. I am Soumya and a part of FunctionUp Uranium cohort")
}
module.exports.welcome = welcome